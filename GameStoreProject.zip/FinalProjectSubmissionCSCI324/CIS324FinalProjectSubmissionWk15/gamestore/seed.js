//these next few lines establish the connection to our database in mongodb compass
const mongoose = require('mongoose')
const connectionString = 'mongodb://127.0.0.1:27017/products'
if(!connectionString) {
    console.error('MongoDB connection string is missing')
    process.exit(1)
}

//this uses mongoose to connect to mongodb via connectionString. we call this connection db from this point forward.
mongoose.connect(connectionString, {useNewUrlParser: true})
const db = mongoose.connection
db.on('error', err=>{
    console.error('MongoDB error: ' + err.message)
    process.exit(1)
})
db.once('open', ()=> console.log('MongoDB connection established'))

//seed product dataset
const Product = require('./product.js')
Product.find((err, products) =>{
    if(err) return console.error(err)
    if(products.length) return

    //4 Trading card products 
    new Product({
    name: 'Magic',
    product_name: 'Magic the Gathering Cards',
    category: 'Trading_Cards',
    item_view: "https://m.media-amazon.com/images/I/513g+EWg93L._AC_SY780_.jpg",
    sku: '001',
    description: 'Fun cards',
    price: "$ 3",
    tags: ['trading cards', 'game', 'competative', 'tabletop', 'mtg'],
    available: true,
    packagesSold: 5,
    }) .save()

    new Product({
    name: 'Pokemon',
    product_name: 'Pokemon Cards',
    category: 'Trading_Cards',
    item_view: "https://media.gamestop.com/i/gamestop/11205670/Pokemon-Trading-Card-Game-Sword-and-Shield---LOST-ORIGIN-Booster-Bundle?fmt=auto",
    sku: '002',
    description: 'Fun cards',
    price: "$ 4",
    tags: ['trading cards', 'game', 'competative', 'tabletop', 'mtg'],
    available: true,
    packagesSold: 3,
    }) .save()

    new Product({
    name: 'Gpk',
    product_name: 'Garbage Pail Kids Cards',
    category: 'Trading_Cards',
    item_view: "https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fstatic.onecms.io%2Fwp-content%2Fuploads%2Fsites%2F6%2F2020%2F02%2Fr-l-stein-2-2000.jpg",
    sku: '003',
    description: 'Gross cards',
    price: "$ 3",
    tags: ['trading cards', 'trade', 'stickers', 'funny', 'gpk'],
    available: true,
    packagesSold: 2,
    }) .save()

    new Product({
    name: 'Ygo',
    product_name: 'YuGiOh Cards',
    category: 'Trading_Cards',
    item_view: "https://tools.toywiz.com/_images/_webp/_products/lg/yugiohdarkworlddeck.webp",
    sku: '004',
    description: 'Bleh cards',
    price: "$ 1",
    tags: ['trading cards', 'trade', 'interesting', 'tabletop', 'YuGiOh'],
    available: true,
    packagesSold: 1,
    }) .save()

    //4 board game products
    new Product({
    name: 'Catan',
    product_name: 'Catan',
    category: 'Board_Games',
    item_view: "https://imgs.michaels.com/MAM/assets/1/5E3C12034D34434F8A9BAAFDDF0F8E1B/img/171DDF9B27E74AC38DB80B303626CFC3/D327359S_1.jpg?fit=inside|1024:1024",
    sku: '005',
    description: 'A fun game',
    price: "$ 5",
    tags: ['board games', 'game', 'strategy', 'tabletop', 'expansion pack'],
    available: true,
    packagesSold: 7,
    }) .save()

    new Product({
    name: 'Dnd',
    product_name: 'Dungeons & Dragons',
    category: 'Board_Games',
    item_view: "https://m.media-amazon.com/images/I/514WQI53GEL._AC_SY780_.jpg",
    sku: '006',
    description: 'A fantasy game',
    price: "$ 10",
    tags: ['board games', 'game', 'fantasy', 'tabletop', 'roleplaying'],
    available: true,
    packagesSold: 20,
    }) .save()

    new Product({
    name: 'Tix',
    product_name: 'Ticket To Ride',
    category: 'Board_Games',
    item_view: "https://m.media-amazon.com/images/I/91YNJM4oyhL.jpg",
    sku: '007',
    description: 'A train game',
    price: "$ 12",
    tags: ['board games', 'game', 'trains', 'tabletop', 'resources'],
    available: true,
    packagesSold: 5,
    }) .save()

    new Product({
    name: 'Towns',
    product_name: 'Tiny Towns',
    category: 'Board_Games',
    item_view: "https://cf.geekdo-images.com/aE1EoOzr530gQin8bj8QDA__opengraph/img/Ip_wNsctDhhyrurz1ESMfwCdaOU=/fit-in/1200x630/filters:strip_icc()/pic4460401.jpg",
    sku: '008',
    description: 'A wholesome game',
    price: "$ 15",
    tags: ['board games', 'game', 'town', 'building', 'animals'],
    available: true,
    packagesSold: 7,
    }) .save()

    //4 video game products
    new Product({
    name: 'Stardew',
    product_name: 'Stardew Valley',
    category: 'Video_Games',
    item_view: "https://e.snmc.io/lk/l/x/b993c2cc055a5f5f6f00f808271b8960/5274911",
    sku: '009',
    description: 'A farming game',
    price: "$ 12",
    tags: ['video games', 'game', 'cute', 'nintendo switch', 'farming'],
    available: true,
    packagesSold: 30,
    }) .save()

    new Product({
    name: 'Potion',
    product_name: 'Potion Permit',
    category: 'Video_Games',
    item_view: "https://www.mobygames.com/images/covers/l/838397-potion-permit-playstation-4-front-cover.jpg",
    sku: '010',
    description: 'Newly released game',
    price: "$ 13",
    tags: ['video games', 'game', 'cute', 'nintendo switch', 'village'],
    available: true,
    packagesSold: 5,
    }) .save()

    new Product({
    name: 'Ragnarok',
    product_name: 'God Of War Ragnarok',
    category: 'Video_Games',
    item_view: "https://media.gamestop.com/i/gamestop/11206962-11206961?fmt=auto",
    sku: '011',
    description: 'Newly released game',
    price: "$ 21",
    tags: ['video games', 'game', 'game of the year 2022', 'ps5', 'adventure'],
    available: true,
    packagesSold: 20,
    }) .save()

    new Product({
    name: 'Elden',
    product_name: 'Elden Ring',
    category: 'Video_Games',
    item_view: "https://media.gamestop.com/i/gamestop/11148586/Elden-Ring----PlayStation-5?fmt=auto",
    sku: '012',
    description: 'Popular game',
    price: "$ 18",
    tags: ['video games', 'game', 'hard game', 'ps5', 'adventure'],
    available: true,
    packagesSold: 20,
    }) .save()
})

//module.exports makes it so that we can use the things we save here in other files as well.
module.exports = {
    getProducts: async (option = {}) => Product.find(options),
}