const mongoose = require('mongoose')

const Product = mongoose.model('products', {
    name: {
        type: String,
        required: true
    },
    product_name: {
        type: String,
        required: true
    },
    category: {
        type: String,
        default: true
    },
    item_view: {
        type: String,
        required: true
    },
    sku: {
        type: String,
        default: true
    },
    description: {
        type: String,
        default: true
    },
    price: {
        type: String,
        required: true
    },
    tags: {
        type: [String],
        default: true
    },
    available: {
        type: Boolean,
        default: true
    },
    packagessold: {
        type: Number,
        default: true
    }
})

module.exports = Product