const express = require('express')
const path = require('path')
const app = express()
const port = process.env.PORT || 3000
const fs = require('fs')
require('./src/db/mongoose')
const Product = require('./src/models/product') 
const Category = require('./src/models/category')

var superagent = require('superagent');

const publicDirectoryPath = path.join(__dirname,'/public')
//line below makes css show up 
app.use(express.static(publicDirectoryPath))

//var url = 'http://localhost:3000/products';

//let rawproductdata = fs.readFileSync('products.json');
//let products = JSON.parse(rawproductdata);


app.set('view engine','hbs')
app.use(express.json())

//route for homepage
app.get('', (req, res) => {
    res.render('index',{
        title:'CIS 324 Game Store App',
        name: 'Gianna Ruggieri'
    })
})

// //specific pages on the site below
app.get('/gamestore/boardgames' , (req, res) => { //displays boardgames page - without this there's a 404 error
    res.render('boardgames')
})
app.get('/gamestore/tradingcards' , (req, res) => { //displays tradingcards page - without this there's a 404 error
  res.render('tradingcards')
})
app.get('/gamestore/videogames' , (req, res) => { //displays videogames page - without this there's a 404 error
  res.render('videogames')
})

//route for product api
app.get('/api/product', (req, res) => {
    Product.find({name: req.query.product}).then((product) => {
        res.send(product)
    }).catch((e) => {
        res.status(500).send()
    })
})

//route for product hbs views
//new super agent logic
app.get('/product', function(req, res, next) {
    superagent.get('http://localhost:3000/api/product')
    .query({ //this refers to the query string param for each product
      product: req.query.product,
    })
    .end(function(err, response) {
      if (err) {
        next(err);
      }
      console.log(response.body[0])
      return res.render('saleitem', response.body[0]);
    })
  });
//route for category api
  app.get('/api/category', (req, res) => {
    Category.find({category: req.query.category}).then((category) => {
        res.send(category)
    }).catch((e) => {
        res.status(500).send()
    })
})
//route for category views
app.get('/category', function(req, res, next) {
    superagent.get('http://localhost:3000/api/category')
    .query({ //this refers to the query string param for each product
      category: req.query.category,
    })
    .end(function(err, response) {
      if (err) {
        next(err);
      }
      console.log(response.body[0])
      return res.render('categories', response.body[0]);
    })
  });

//route for everything else/error pages
app.get('*', (req, res) => {
    res.render('404',{
        title:'Game Store Error Page',
        name: '@Gianna Ruggieri- Contact for assitance',
        errorMessage: 'This product does not yet exist!'
    })
})

app.listen(3000, () =>{
    console.log("gamestore app listening on port 3000 ")
    //console.log(products)
    //console.log(publicDirectoryPath)
})